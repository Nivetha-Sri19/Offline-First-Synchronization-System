from __future__ import annotations

from fastapi import APIRouter, Depends

from app.api.deps import get_current_user, get_sync_service
from app.models.user import User
from app.schemas.sync.request import SyncBatchRequest
from app.schemas.sync.response import SyncBatchResponse
from app.services.synchronization.sync_service import SyncService

router = APIRouter(
    prefix="/sync",
    tags=["Synchronization"],
)


@router.post(
    "/batch",
    response_model=SyncBatchResponse,
)
def synchronize(
    request: SyncBatchRequest,
    current_user: User = Depends(get_current_user),
    service: SyncService = Depends(get_sync_service),
) -> SyncBatchResponse:
    return service.process_batch(
        user_id=current_user.id,
        request=request,
    )