from __future__ import annotations

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.api.deps import get_current_user, get_db
from app.models.user import User
from app.repositories.user_repository import UserRepository
from app.schemas.auth.request import UserProfileUpdateRequest
from app.schemas.auth.response import UserResponse

router = APIRouter(
    prefix="/users",
    tags=["Users"],
)


@router.patch(
    "/me",
    response_model=UserResponse,
)
def update_profile(
    request: UserProfileUpdateRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
) -> User:
    if request.full_name is not None:
        current_user.full_name = request.full_name

    return UserRepository(db).update(current_user)