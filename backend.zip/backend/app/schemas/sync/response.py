from __future__ import annotations

import uuid
from datetime import datetime

from pydantic import BaseModel


class SyncOperationResponse(BaseModel):
    operation_id: uuid.UUID
    record_id: uuid.UUID
    status: str
    conflict_status: str
    server_version: int | None = None
    message: str | None = None
    error: str | None = None


class SyncBatchResponse(BaseModel):
    total_operations: int
    successful_operations: int
    failed_operations: int
    conflict_operations: int
    results: list[SyncOperationResponse]


class SyncHistoryResponse(BaseModel):
    sync_id: uuid.UUID
    operation_id: uuid.UUID
    record_id: uuid.UUID
    operation_type: str
    status: str
    timestamp: datetime
    error_details: str | None
    conflict_status: str


class SyncStatisticsResponse(BaseModel):
    pending_changes: int
    successful_syncs: int
    failed_syncs: int
    conflicts: int
    total_syncs: int
    last_sync_at: datetime | None


class SyncDashboardResponse(BaseModel):
    statistics: SyncStatisticsResponse
    recent_syncs: list[SyncHistoryResponse]