from __future__ import annotations

from collections.abc import Generator

from sqlalchemy import Engine, create_engine
from sqlalchemy.orm import Session, sessionmaker


class DatabaseSessionManager:
    """
    Centralized SQLAlchemy engine and session manager.

    The actual database URL is injected when the application starts.
    Keeping the manager independent from configuration prevents circular
    imports between the database and core layers.
    """

    def __init__(
        self,
        database_url: str,
        *,
        pool_size: int = 10,
        max_overflow: int = 20,
        pool_timeout: int = 30,
        pool_recycle: int = 1800,
        echo: bool = False,
    ) -> None:
        self.engine: Engine = create_engine(
            database_url,
            pool_pre_ping=True,
            pool_recycle=pool_recycle,
            pool_size=pool_size,
            max_overflow=max_overflow,
            pool_timeout=pool_timeout,
            echo=echo,
            future=True,
        )

        self.session_factory = sessionmaker(
            bind=self.engine,
            class_=Session,
            autoflush=False,
            expire_on_commit=False,
            autocommit=False,
        )

    def get_session(self) -> Session:
        """
        Return a new SQLAlchemy session.
        """
        return self.session_factory()

    def session_dependency(self) -> Generator[Session, None, None]:
        """
        FastAPI dependency that creates and safely closes a database session.
        """
        session = self.get_session()

        try:
            yield session
        finally:
            session.close()

    def dispose(self) -> None:
        """
        Dispose the connection pool.

        Called during application shutdown.
        """
        self.engine.dispose()