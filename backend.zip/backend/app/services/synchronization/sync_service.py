from __future__ import annotations

import uuid
from datetime import UTC, datetime

from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.core.constants import SyncOperationStatus
from app.core.exceptions import ResourceConflictError
from app.models.local_sync_operation import LocalSyncOperation
from app.models.sync_history import SyncHistory
from app.repositories.conflict_repository import ConflictRepository
from app.repositories.record_repository import RecordRepository
from app.repositories.sync_repository import SyncRepository
from app.schemas.sync.request import SyncBatchRequest
from app.schemas.sync.response import (
    SyncBatchResponse,
    SyncOperationResponse,
)
from app.services.synchronization.sync_processor import SyncProcessor


class SyncService:
    def __init__(
        self,
        session: Session,
        sync_repository: SyncRepository,
        record_repository: RecordRepository,
        conflict_repository: ConflictRepository,
    ) -> None:
        self.session = session
        self.sync_repository = sync_repository
        self.record_repository = record_repository
        self.conflict_repository = conflict_repository

    def process_batch(
        self,
        *,
        user_id: uuid.UUID,
        request: SyncBatchRequest,
    ) -> SyncBatchResponse:
        results: list[SyncOperationResponse] = []

        successful = 0
        failed = 0
        conflicts = 0

        for operation_request in request.operations:
            try:
                result = self._process_operation(
                    user_id=user_id,
                    operation_request=operation_request,
                )

                results.append(result)

                if result.status == SyncOperationStatus.SUCCESS:
                    successful += 1
                elif result.status == SyncOperationStatus.CONFLICT:
                    conflicts += 1
                else:
                    failed += 1

            except Exception as exc:
                self.session.rollback()

                results.append(
                    SyncOperationResponse(
                        operation_id=operation_request.operation_id,
                        record_id=operation_request.record_id,
                        status=SyncOperationStatus.FAILED,
                        conflict_status="none",
                        message="Synchronization failed.",
                        error=str(exc),
                    )
                )

                failed += 1

        return SyncBatchResponse(
            total_operations=len(request.operations),
            successful_operations=successful,
            failed_operations=failed,
            conflict_operations=conflicts,
            results=results,
        )

    def _process_operation(
        self,
        *,
        user_id: uuid.UUID,
        operation_request,
    ) -> SyncOperationResponse:
        existing = self.sync_repository.get_operation(
            operation_request.operation_id
        )

        if existing is not None:
            return self._existing_operation_response(existing)

        operation = LocalSyncOperation(
            operation_id=operation_request.operation_id,
            record_id=operation_request.record_id,
            user_id=user_id,
            operation_type=operation_request.operation_type.value,
            base_version=operation_request.base_version,
            payload=operation_request.payload,
            status=SyncOperationStatus.PROCESSING,
            attempt_count=1,
        )

        try:
            self.sync_repository.create_operation(operation)
        except IntegrityError as err:
            self.session.rollback()

            existing = self.sync_repository.get_operation(
                operation_request.operation_id
            )

            if existing is None:
                raise ResourceConflictError(
                    "Synchronization operation could not be created."
                ) from err

            return self._existing_operation_response(existing)

        processor = SyncProcessor(
            session=self.session,
            record_repository=self.record_repository,
            sync_repository=self.sync_repository,
            conflict_repository=self.conflict_repository,
        )

        try:
            status, conflict_status, server_version = processor.process(
                user_id=user_id,
                operation=operation,
            )

            operation.status = status
            operation.processed_at = datetime.now(UTC)

            if status == SyncOperationStatus.CONFLICT:
                operation.error_message = (
                    "Synchronization conflict detected."
                )

            history = SyncHistory(
                sync_id=uuid.uuid4(),
                operation_id=operation.operation_id,
                record_id=operation.record_id,
                user_id=user_id,
                operation_type=operation.operation_type,
                status=status,
                conflict_status=conflict_status,
            )

            self.sync_repository.create_history(history)
            self.sync_repository.update_operation(operation)

            self.session.commit()

            return SyncOperationResponse(
                operation_id=operation.operation_id,
                record_id=operation.record_id,
                status=status,
                conflict_status=conflict_status,
                server_version=server_version,
                message=(
                    "Synchronization completed."
                    if status == SyncOperationStatus.SUCCESS
                    else "Synchronization conflict detected."
                ),
            )

        except Exception:
            self.session.rollback()
            raise

    @staticmethod
    def _existing_operation_response(
        operation: LocalSyncOperation,
    ) -> SyncOperationResponse:
        return SyncOperationResponse(
            operation_id=operation.operation_id,
            record_id=operation.record_id,
            status=operation.status,
            conflict_status=(
                "unresolved"
                if operation.status == SyncOperationStatus.CONFLICT
                else "none"
            ),
            message="Operation already processed.",
            error=operation.error_message,
        )